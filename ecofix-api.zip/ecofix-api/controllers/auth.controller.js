import Customer from "../database/customer.js";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { registerSchema, loginSchema } from "../utils/validators.js";

export const register = async (req, res, next) => {
  try {
    // Validação dos dados de entrada
    const { error } = registerSchema.validate(req.body);
    if (error) return res.status(400).json({ message: error.details[0].message });

    const { customer_name, customer_email, customer_password } = req.body;
    const hash = await bcrypt.hash(customer_password, 10);
    await Customer.create({
      customer_name,
      customer_email,
      customer_password: hash,
    });
    res.status(201).json({ message: "Cliente registrado com sucesso" });
  } catch (err) {
    next(err);
  }
};

export const login = async (req, res, next) => {
  try {
    const { error } = loginSchema.validate(req.body);
    if (error) return res.status(400).json({ message: error.details[0].message });

    const { customer_email, customer_password } = req.body;
    const customer = await Customer.findOne({ where: { customer_email } });
    if (!customer || !(await bcrypt.compare(customer_password, customer.customer_password))) {
      return res.status(401).json({ message: "Credenciais inválidas" });
    }
    const token = jwt.sign({ id: customer.customer_id }, process.env.JWT_SECRET, {
      expiresIn: "1h",
    });
    res.json({ token });
  } catch (err) {
    next(err);
  }
};