import RepairRequest from "../database/repairRequest.js";
import { repairRequestSchema } from "../utils/validators.js";

export const createRepairRequest = async (req, res, next) => {
  try {
    const { error } = repairRequestSchema.validate(req.body);
    if (error) return res.status(400).json({ message: error.details[0].message });

    const repairRequest = await RepairRequest.create({
      request_date: req.body.request_date,
      description: req.body.description,
      customer_id: req.user.id,
      repairer_id: req.body.repairer_id,
    });
    res.status(201).json(repairRequest);
  } catch (err) {
    next(err);
  }
};

export const getRepairRequests = async (req, res, next) => {
  try {
    const requests = await RepairRequest.findAll({
      where: { customer_id: req.user.id },
    });
    res.json(requests);
  } catch (err) {
    next(err);
  }
};

export const updateRepairRequest = async (req, res, next) => {
  try {
    const { id } = req.params;
    const request = await RepairRequest.findByPk(id);
    if (!request) return res.status(404).json({ message: "Solicitação não encontrada" });

    // Permite atualização apenas se o cliente for o dono
    if (request.customer_id !== req.user.id)
      return res.status(403).json({ message: "Acesso negado" });

    await request.update(req.body);
    res.json(request);
  } catch (err) {
    next(err);
  }
};

export const deleteRepairRequest = async (req, res, next) => {
  try {
    const { id } = req.params;
    const request = await RepairRequest.findByPk(id);
    if (!request) return res.status(404).json({ message: "Solicitação não encontrada" });

    if (request.customer_id !== req.user.id)
      return res.status(403).json({ message: "Acesso negado" });

    await request.destroy();
    res.json({ message: "Solicitação removida com sucesso" });
  } catch (err) {
    next(err);
  }
};