import { Sequelize } from "sequelize";
import sequelize from "./database.js";

const Repairer = sequelize.define("Repairer", {
  repairer_id: {
    type: Sequelize.STRING, // Pode ser um código ou registro único
    allowNull: false,
    primaryKey: true,
  },
  repairer_name: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  repairer_email: {
    type: Sequelize.STRING,
    allowNull: false,
    unique: true,
  },
});

export default Repairer;