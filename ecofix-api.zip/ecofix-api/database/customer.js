import { Sequelize } from "sequelize";
import sequelize from "./database.js";

const Customer = sequelize.define("Customer", {
  customer_id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  customer_name: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  customer_email: {
    type: Sequelize.STRING,
    allowNull: false,
    unique: true,
  },
  customer_password: {
    type: Sequelize.STRING,
    allowNull: false,
  },
});

export default Customer;