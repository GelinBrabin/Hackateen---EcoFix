import { Sequelize } from "sequelize";
import sequelize from "./database.js";
import Customer from "./customer.js";
import Repairer from "./repairer.js";

const RepairRequest = sequelize.define("RepairRequest", {
  request_id: {
    type: Sequelize.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  request_date: {
    type: Sequelize.STRING,
    allowNull: false,
  },
  description: {
    type: Sequelize.STRING,
    allowNull: false,
  },
});

Customer.hasMany(RepairRequest, { foreignKey: "customer_id" });
RepairRequest.belongsTo(Customer, { foreignKey: "customer_id" });

Repairer.hasMany(RepairRequest, { foreignKey: "repairer_id" });
RepairRequest.belongsTo(Repairer, { foreignKey: "repairer_id" });

export default RepairRequest;