import winston from 'winston';

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    // Você pode adicionar um transport para arquivo:
    // new winston.transports.File({ filename: 'error.log', level: 'error' })
  ],
});

export default logger;