import Joi from 'joi';

export const registerSchema = Joi.object({
  customer_name: Joi.string().required(),
  customer_email: Joi.string().email().required(),
  customer_password: Joi.string().min(6).required(),
});

export const loginSchema = Joi.object({
  customer_email: Joi.string().email().required(),
  customer_password: Joi.string().required(),
});

export const repairRequestSchema = Joi.object({
  request_date: Joi.string().required(),
  description: Joi.string().required(),
  repairer_id: Joi.string().required(),
});