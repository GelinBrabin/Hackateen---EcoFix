import express from "express";
import {
  createRepairRequest,
  getRepairRequests,
  updateRepairRequest,
  deleteRepairRequest,
} from "../controllers/repair.controller.js";
import authMiddleware from "../middleware/auth.js";

const router = express.Router();

/**
 * @swagger
 * /api/repairs:
 *   post:
 *     tags: [Repair Requests]
 *     summary: Criar uma nova solicitação de reparo
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               request_date:
 *                 type: string
 *               description:
 *                 type: string
 *               repairer_id:
 *                 type: string
 *     responses:
 *       201:
 *         description: Solicitação criada com sucesso.
 */
router.post("/", authMiddleware, createRepairRequest);

/**
 * @swagger
 * /api/repairs:
 *   get:
 *     tags: [Repair Requests]
 *     summary: Listar solicitações de reparo do cliente autenticado
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de solicitações.
 */
router.get("/", authMiddleware, getRepairRequests);

/**
 * @swagger
 * /api/repairs/{id}:
 *   put:
 *     tags: [Repair Requests]
 *     summary: Atualizar uma solicitação de reparo
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID da solicitação
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               request_date:
 *                 type: string
 *               description:
 *                 type: string
 *     responses:
 *       200:
 *         description: Solicitação atualizada com sucesso.
 */
router.put("/:id", authMiddleware, updateRepairRequest);

/**
 * @swagger
 * /api/repairs/{id}:
 *   delete:
 *     tags: [Repair Requests]
 *     summary: Deletar uma solicitação de reparo
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: integer
 *         description: ID da solicitação
 *     responses:
 *       200:
 *         description: Solicitação removida com sucesso.
 */
router.delete("/:id", authMiddleware, deleteRepairRequest);

export default router;