import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import sequelize from "./database/database.js";

import authRoutes from "./routes/auth.routes.js";
import repairRoutes from "./routes/repair.routes.js";
import errorHandler from "./middleware/errorHandler.js";

import swaggerJsdoc from "swagger-jsdoc";
import swaggerUi from "swagger-ui-express";

import Repairer from "./database/repairer.js";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const swaggerOptions = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "EcoFix API",
      version: "1.0.0",
      description: "Dando uma nova vida ao seus objetos",
    },
    servers: [{ url: `http://localhost:${process.env.PORT || 3000}` }],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: "http",
          scheme: "bearer",
          bearerFormat: "JWT",
        },
      },
    },
    security: [{ bearerAuth: [] }],
  },
  apis: ["./routes/*.js"],
};

const swaggerDocs = swaggerJsdoc(swaggerOptions);
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocs));

app.use("/api/auth", authRoutes);
app.use("/api/repairs", repairRoutes);

app.use(errorHandler);

const seedRepairer = async () => {
  try {
    const [repairer, created] = await Repairer.findOrCreate({
      where: { repairer_id: "RP001" },
      defaults: {
        repairer_name: "Carlos Souza",
        repairer_email: "carlos.souza@example.com",
      },
    });

    if (created) {
      console.log("Repairer inserido no banco com sucesso!");
    } else {
      console.log("Repairer já estava presente no banco.");
    }
  } catch (error) {
    console.error("Erro ao inserir o Repairer:", error);
  }
};

if (process.env.NODE_ENV !== "test") {
  const PORT = process.env.PORT || 3000;
  sequelize.sync().then(async () => {
    console.log("Banco de dados sincronizado!");

    // Chama a função para semear o Repairer no banco de dados
    await seedRepairer();

    app.listen(PORT, () =>
      console.log(`Servidor rodando na porta ${PORT}`)
    );
  });
}

export default app;