import request from "supertest";
import app from "../app.js";
import sequelize from "../database/database.js";

beforeAll(async () => {
  await sequelize.sync({ force: true });
});

afterAll(async () => {
  await sequelize.close();
});

describe("Auth Endpoints", () => {
  it("deve registrar um novo cliente", async () => {
    const res = await request(app)
      .post("/api/auth/register")
      .send({
        customer_name: "Teste Cliente",
        customer_email: "teste@exemplo.com",
        customer_password: "123456"
      });
    expect(res.statusCode).toEqual(201);
    expect(res.body).toHaveProperty("message", "Cliente registrado com sucesso");
  });

  it("deve fazer login e retornar um token", async () => {
    const res = await request(app)
      .post("/api/auth/login")
      .send({
        customer_email: "teste@exemplo.com",
        customer_password: "123456"
      });
    expect(res.statusCode).toEqual(200);
    expect(res.body).toHaveProperty("token");
  });
});